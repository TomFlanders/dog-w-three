# dog-w-three
WordPress theme based on w3.css. Designed to be fast, responsive and accessible.
