<div class="w3-container w3-small w3-row w3-center" style="padding-top: 5px">
Copyright 2016 Tom Flanders - Most rights reserved
</div>
<?php wp_footer(); ?>
</body>
</html>
