=== dog-w-three ===

dog-w-three WordPress theme, Copyright (C) 2016 Tom Flanders
dog-w-three WordPress theme is licensed under the GPL.

For support, please post in the forums at http://wordpress.org

== Description ==

dog-w-three is based on w3.css (http://www.w3schools.com/w3css/). It is intended for simple blogs.
It is responsive, accessible and relatively fast.

== Installation ==
Manual installation:

1. Upload the `dog-w-three` folder to the `/wp-content/themes/` directory

Activiation and Use

1. Activate the Theme through the 'Themes' menu in WordPress

== Default image ==
Default logo image from theme screenshot you can find at /dog-w-three/images/

== License ==
Unless otherwise specified, all the theme files, scripts and images
are licensed under GNU General Public License version 2, see http://www.gnu.org/licenses/gpl-2.0.html.

== Version history ==
1.0 Just the beginning
